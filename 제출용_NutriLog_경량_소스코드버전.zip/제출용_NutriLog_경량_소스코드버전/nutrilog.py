import customtkinter as ctk
from tkinter import messagebox, filedialog
import re
import threading
import json
import os
import datetime
from g4f.client import Client

# 음식 사전 (오프라인 폴백용)
FOOD_DB = {
    "삶은계란": {"unit": "개", "kcal": 70, "c": 1, "p": 6, "f": 5},
    "계란": {"unit": "개", "kcal": 70, "c": 1, "p": 6, "f": 5},
    "공기밥": {"unit": "공기", "kcal": 300, "c": 65, "p": 6, "f": 0.5},
    "밥": {"unit": "공기", "kcal": 300, "c": 65, "p": 6, "f": 0.5},
    "라면": {"unit": "개", "kcal": 500, "c": 75, "p": 10, "f": 15},
    "김치찌개": {"unit": "인분", "kcal": 400, "c": 20, "p": 25, "f": 25},
    "된장찌개": {"unit": "인분", "kcal": 300, "c": 20, "p": 15, "f": 15},
    "삼겹살": {"unit": "인분", "kcal": 650, "c": 2, "p": 40, "f": 55},
    "치킨": {"unit": "마리", "kcal": 2000, "c": 150, "p": 120, "f": 100},
    "짜장면": {"unit": "그릇", "kcal": 800, "c": 120, "p": 20, "f": 25},
    "짬뽕": {"unit": "그릇", "kcal": 700, "c": 100, "p": 30, "f": 20},
    "피자": {"unit": "조각", "kcal": 250, "c": 30, "p": 10, "f": 10},
    "햄버거": {"unit": "개", "kcal": 450, "c": 45, "p": 25, "f": 20},
    "닭가슴살": {"unit": "개", "kcal": 110, "c": 0, "p": 23, "f": 1},
    "우유": {"unit": "잔", "kcal": 130, "c": 10, "p": 6, "f": 7},
    "고구마": {"unit": "개", "kcal": 130, "c": 30, "p": 2, "f": 0},
    "바나나": {"unit": "개", "kcal": 105, "c": 27, "p": 1, "f": 0},
    "사과": {"unit": "개", "kcal": 95, "c": 25, "p": 0, "f": 0},
    "샐러드": {"unit": "인분", "kcal": 150, "c": 10, "p": 5, "f": 5},
    "떡볶이": {"unit": "인분", "kcal": 550, "c": 100, "p": 12, "f": 5},
}

# 외관 설정 (프리미엄 세팅)
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class NutriLogApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        self.today_str = datetime.date.today().isoformat()
        self.db_file = "nutrilog_db.json"

        self.title("NutriLog Premium - AI 기반 헬스 & 영양 매니저")
        self.geometry("650x950")

        # 내부 변수 초기화
        self.daily_log = []
        self.burned_kcal = 0
        self.water_glasses = 0
        self.targets = {"kcal": 2500, "p": 150, "c": 300, "f": 70}
        self.phys_info = {"h": "", "w": "", "goal": "유지"}

        # 앱 시작시 DB 로드
        self.load_data()
        
        # UI 세팅
        self.setup_ui()
        
        # 로드된 데이터 화면에 그리기
        self.height_entry.insert(0, self.phys_info["h"])
        self.weight_entry.insert(0, self.phys_info["w"])
        self.goal_var.set(self.phys_info["goal"])
        self.water_label.configure(text=f"{self.water_glasses} 잔 / 8 잔")
        self.update_history()
        self.update_dashboard()

    def load_data(self):
        if os.path.exists(self.db_file):
            try:
                with open(self.db_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                if self.today_str in data:
                    today_data = data[self.today_str]
                    self.daily_log = today_data.get("daily_log", [])
                    self.burned_kcal = today_data.get("burned_kcal", 0)
                    self.water_glasses = today_data.get("water_glasses", 0)
                    self.targets = today_data.get("targets", self.targets)
                    self.phys_info = today_data.get("phys_info", self.phys_info)
            except Exception as e:
                print("DB Load Error:", e)

    def save_data(self):
        data = {}
        if os.path.exists(self.db_file):
            try:
                with open(self.db_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except:
                pass
        
        data[self.today_str] = {
            "daily_log": self.daily_log,
            "burned_kcal": self.burned_kcal,
            "water_glasses": self.water_glasses,
            "targets": self.targets,
            "phys_info": self.phys_info
        }
        
        try:
            with open(self.db_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print("DB Save Error:", e)

    def setup_ui(self):
        # 전체를 감싸는 메인 스크롤 프레임 구성
        self.main_scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.main_scroll.pack(fill="both", expand=True)

        # 헤더
        self.header_frame = ctk.CTkFrame(self.main_scroll, fg_color="transparent")
        self.header_frame.pack(pady=(20, 5), fill="x", padx=20)
        self.header_frame.grid_columnconfigure(0, weight=1)
        
        self.header = ctk.CTkLabel(self.header_frame, text="NutriLog Premium✨", font=ctk.CTkFont(size=30, weight="bold"))
        self.header.grid(row=0, column=0, sticky="w")
        
        self.export_btn = ctk.CTkButton(self.header_frame, text="📑 엑셀(CSV) 내보내기", command=self.export_csv, 
                                        fg_color="#8b5cf6", hover_color="#7c3aed", font=ctk.CTkFont(weight="bold"), width=140)
        self.export_btn.grid(row=0, column=1, padx=5, sticky="e")
        
        self.reset_btn = ctk.CTkButton(self.header_frame, text="🗑️ 데이터 초기화", command=self.reset_today_data,
                                       fg_color="#f43f5e", hover_color="#e11d48", font=ctk.CTkFont(weight="bold"), width=120)
        self.reset_btn.grid(row=0, column=2, padx=5, sticky="e")

        # -----------------------------
        # 1. 신체 정보 입력 섹션
        # -----------------------------
        self.phys_frame = ctk.CTkFrame(self.main_scroll, fg_color="gray15")
        self.phys_frame.pack(pady=10, padx=20, fill="x")
        
        ctk.CTkLabel(self.phys_frame, text="👤 내 신체 정보 및 목표 설정", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        self.input_phys_inner = ctk.CTkFrame(self.phys_frame, fg_color="transparent")
        self.input_phys_inner.pack(pady=10)

        # 키 입력 (라벨 + 입력란)
        ctk.CTkLabel(self.input_phys_inner, text="📏 키 :", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=(10, 5), pady=5)
        self.height_entry = ctk.CTkEntry(self.input_phys_inner, placeholder_text="예: 175", width=80)
        self.height_entry.grid(row=0, column=1, padx=(0, 20), pady=5)
        ctk.CTkLabel(self.input_phys_inner, text="cm", font=ctk.CTkFont(size=12)).grid(row=0, column=2, padx=(0, 20), sticky="w")

        # 몸무게 입력 (라벨 + 입력란)
        ctk.CTkLabel(self.input_phys_inner, text="⚖️ 몸무게 :", font=ctk.CTkFont(weight="bold")).grid(row=0, column=3, padx=(10, 5), pady=5)
        self.weight_entry = ctk.CTkEntry(self.input_phys_inner, placeholder_text="예: 70", width=80)
        self.weight_entry.grid(row=0, column=4, padx=(0, 20), pady=5)
        ctk.CTkLabel(self.input_phys_inner, text="kg", font=ctk.CTkFont(size=12)).grid(row=0, column=5, padx=(0, 10), sticky="w")

        self.goal_var = ctk.StringVar(value="유지")
        self.goal_segment = ctk.CTkSegmentedButton(self.phys_frame, values=["다이어트", "유지", "벌크업"], variable=self.goal_var,
                                                   selected_color="#10b981", selected_hover_color="#059669")
        self.goal_segment.pack(pady=10)

        self.analyze_phys_btn = ctk.CTkButton(self.phys_frame, text="피지컬 분석 및 저장", 
                                             command=self.analyze_physical, fg_color="#10b981", hover_color="#059669", font=ctk.CTkFont(weight="bold"))
        self.analyze_phys_btn.pack(pady=10)

        # -----------------------------
        # 2. 물 & 운동 트래커 섹션
        # -----------------------------
        self.extra_frame = ctk.CTkFrame(self.main_scroll, fg_color="transparent")
        self.extra_frame.pack(pady=5, padx=20, fill="x")
        self.extra_frame.grid_columnconfigure((0, 1), weight=1)

        # 수분
        self.water_box = ctk.CTkFrame(self.extra_frame, corner_radius=10, border_width=1, border_color="#3b82f6")
        self.water_box.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        ctk.CTkLabel(self.water_box, text="💧 수분 섭취", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        self.water_label = ctk.CTkLabel(self.water_box, text="0 잔 / 8 잔", font=ctk.CTkFont(size=18, weight="bold"), text_color="#60a5fa")
        self.water_label.pack(pady=5)
        self.add_water_btn = ctk.CTkButton(self.water_box, text="+ 1잔 (250ml)", command=self.add_water, 
                                           width=100, fg_color="#3b82f6", hover_color="#2563eb", font=ctk.CTkFont(weight="bold"))
        self.add_water_btn.pack(pady=10)

        # 운동
        self.exercise_box = ctk.CTkFrame(self.extra_frame, corner_radius=10, border_width=1, border_color="#ef4444")
        self.exercise_box.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
        ctk.CTkLabel(self.exercise_box, text="🏃 오늘 운동 기록", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        # 강도 선택 버튼 추가
        self.intensity_var = ctk.StringVar(value="중강도")
        self.intensity_seg = ctk.CTkSegmentedButton(self.exercise_box, values=["저강도", "중강도", "고강도"], 
                                                    variable=self.intensity_var, selected_color="#ef4444", height=25)
        self.intensity_seg.pack(pady=2, padx=10, fill="x")
        
        self.exercise_entry = ctk.CTkEntry(self.exercise_box, placeholder_text="예: 달리기 30분", width=140)
        self.exercise_entry.pack(pady=5, padx=10)
        self.add_exercise_btn = ctk.CTkButton(self.exercise_box, text="AI 칼로리 계산 반영", command=self.add_exercise, 
                                              width=100, fg_color="#ef4444", hover_color="#dc2626", font=ctk.CTkFont(weight="bold"))
        self.add_exercise_btn.pack(pady=5)

        # -----------------------------
        # 3. 비주얼 영양 현황 대시보드
        # -----------------------------
        self.dashboard_frame = ctk.CTkFrame(self.main_scroll, fg_color="transparent")
        self.dashboard_frame.pack(pady=10, padx=10, fill="x")

        self.kcal_card, self.kcal_pb = self.create_stat_card(self.dashboard_frame, "Kalories", "0 / ---", 0, 0, "#10b981")
        self.protein_card, self.protein_pb = self.create_stat_card(self.dashboard_frame, "Protein", "0g / ---", 0, 1, "#f43f5e")
        self.carbs_card, self.carbs_pb = self.create_stat_card(self.dashboard_frame, "Carbs", "0g / ---", 1, 0, "#0ea5e9")
        self.fat_card, self.fat_pb = self.create_stat_card(self.dashboard_frame, "Fat", "0g / ---", 1, 1, "#f59e0b")

        # -----------------------------
        # 4. 맞춤 개선 방안 메시지 칸
        # -----------------------------
        self.advice_title = ctk.CTkLabel(self.main_scroll, text="💡 AI 맞춤 식단 솔루션", font=ctk.CTkFont(size=14, weight="bold"), text_color="#10b981")
        self.advice_title.pack(pady=(20, 0))

        self.advice_frame = ctk.CTkFrame(self.main_scroll, fg_color="#1e293b", border_width=1, border_color="#334155")
        self.advice_frame.pack(pady=5, padx=20, fill="x")
        self.advice_label = ctk.CTkLabel(self.advice_frame, text="키와 몸무게를 입력하고 피지컬 분석 버튼을 눌러주세요.", 
                                         wraplength=500, font=ctk.CTkFont(size=13), justify="left")
        self.advice_label.pack(pady=20, padx=20)

        # -----------------------------
        # 5. 자연어 식단 입력 섹션
        # -----------------------------
        self.input_frame = ctk.CTkFrame(self.main_scroll)
        self.input_frame.pack(pady=20, padx=20, fill="x")
        self.input_frame.grid_columnconfigure(0, weight=1)
        
        self.input_title = ctk.CTkLabel(self.input_frame, text="🍽️ 식단 추가 (자연어로 말해보세요!)", font=ctk.CTkFont(weight="bold"))
        self.input_title.grid(row=0, column=0, pady=10)
        
        self.natural_input_entry = ctk.CTkEntry(self.input_frame, placeholder_text="예: 계란 2개랑 우유 한잔 먹었어", height=40)
        self.natural_input_entry.grid(row=1, column=0, pady=10, padx=20, sticky="ew")
        
        self.natural_input_entry.bind("<Return>", lambda e: self.add_food_smart())

        self.add_btn = ctk.CTkButton(self.input_frame, text="AI 스마트 분석 후 기록 추가", command=self.add_food_smart, 
                                     font=ctk.CTkFont(weight="bold", size=14), fg_color="#6366f1", hover_color="#4f46e5", height=40)
        self.add_btn.grid(row=2, column=0, pady=(10, 20), padx=20, sticky="ew")

        # -----------------------------
        # 6. 식단 섭취 내역
        # -----------------------------
        self.history_frame_title = ctk.CTkLabel(self.main_scroll, text="📝 오늘의 섭취 내역", font=ctk.CTkFont(size=15, weight="bold"))
        self.history_frame_title.pack(pady=(10, 5), padx=30, anchor="w")
        self.history_scroll = ctk.CTkFrame(self.main_scroll, fg_color="transparent")
        self.history_scroll.pack(pady=5, padx=30, fill="x")

    def create_stat_card(self, parent, label, value, row, col, color):
        card = ctk.CTkFrame(parent, corner_radius=15, border_width=1, border_color="gray30")
        card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
        parent.grid_columnconfigure(col, weight=1)
        
        lbl_label = ctk.CTkLabel(card, text=label, font=ctk.CTkFont(size=14, weight="bold"), text_color="gray")
        lbl_label.pack(pady=(15, 0))
        
        val_label = ctk.CTkLabel(card, text=value, font=ctk.CTkFont(size=18, weight="bold"), text_color=color)
        val_label.pack(pady=(5, 10))
        
        pb = ctk.CTkProgressBar(card, height=8, progress_color=color)
        pb.pack(fill="x", padx=20, pady=(0, 20))
        pb.set(0)
        
        return val_label, pb

    def export_csv(self):
        import csv
        if not os.path.exists(self.db_file):
            messagebox.showwarning("데이터 없음", "저장된 기록이 없습니다.")
            return
            
        with open(self.db_file, "r", encoding="utf-8") as f:
            data = json.load(f)
            
        # 파일 저장 대화상자 띄우기 (바탕화면을 기본으로)
        initial_file = f"NutriLog_주간리포트_{self.today_str}.csv"
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=initial_file,
            title="데이터 내보내기 저장 위치 선택"
        )
        
        if not file_path: # 취소 시
            return
            
        try:
            with open(file_path, "w", newline='', encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow(["날짜", "목표(Kcal)", "섭취(Kcal)", "단백질(g)", "탄수화물(g)", "지방(g)", "수분(잔)", "운동소모(Kcal)"])
                for date, info in data.items():
                    targets = info.get("targets", {})
                    t_kcal = targets.get("kcal", 0)
                    burned = info.get("burned_kcal", 0)
                    water = info.get("water_glasses", 0)
                    
                    c_kcal = sum(item["info"]["kcal"] for item in info.get("daily_log", []))
                    c_p = sum(item["info"]["p"] for item in info.get("daily_log", []))
                    c_c = sum(item["info"]["c"] for item in info.get("daily_log", []))
                    c_f = sum(item["info"]["f"] for item in info.get("daily_log", []))
                    
                    writer.writerow([date, t_kcal, int(c_kcal), round(c_p, 1), round(c_c, 1), round(c_f, 1), water, burned])
            messagebox.showinfo("내보내기 성공", f"선택하신 위치에 파일이 성공적으로 저장되었습니다!")
        except Exception as e:
            messagebox.showerror("에러", f"파일 저장 중 에러가 발생했습니다: {e}")

    def add_water(self):
        self.water_glasses += 1
        self.water_label.configure(text=f"{self.water_glasses} 잔 / 8 잔")
        self.save_data()
    def reset_today_data(self):
        if messagebox.askyesno("전체 초기화", "정말 오늘 하루의 모든 기록(식단, 운동, 수분)을 삭제하시겠습니까?"):
            self.daily_log = []
            self.water_glasses = 0
            self.burned_kcal = 0
            # 신체 분석 정보는 유지하도록 설계 (타겟 등)
            
            self.save_data()
            self.update_history()
            self.update_dashboard()
            self.water_label.configure(text="0 잔 / 8 잔")
            messagebox.showinfo("초기화 완료", "오늘의 모든 데이터가 초기화되었습니다.")
    def add_exercise(self):
        text = self.exercise_entry.get().strip()
        intensity = self.intensity_var.get()
        if not text: return
        self.add_exercise_btn.configure(text="AI 계산...", state="disabled")
        
        def worker():
            try:
                client = Client()
                prompt = f"""
                Exercise Input: "{text}"
                Intensity selection: "{intensity}"
                
                STRICT RULES:
                1. Check if the input describes a REAL physical activity. If it's a joke, a metabolic process (breathing), or trivial movement (finger moving, typing), return ONLY "0".
                2. Check if the input specifies a QUANTITY (e.g., 30 mins, 5 km, 1 hour). 
                   - If NO numbers related to time or distance are present, return ONLY "-1".
                   - Do NOT guess the duration. Even if intensity is selected, do not return a result without a number in the input text.
                3. If it's valid and has quantity, estimate kcal burn for an average adult.
                
                Output ONLY a single integer (result, 0, or -1).
                """
                response = client.chat.completions.create(model="gpt-4", messages=[{"role": "user", "content": prompt}])
                res_text = response.choices[0].message.content.strip()
                match = re.search(r'-?\d+', res_text)
                val = int(match.group(0)) if match else 0
                self.after(0, self.on_exercise_finish, text, intensity, val)
            except:
                self.after(0, self.on_exercise_finish, text, intensity, 0)
                
        threading.Thread(target=worker, daemon=True).start()
        
    def on_exercise_finish(self, text, intensity, val):
        self.add_exercise_btn.configure(text="AI 칼로리 계산 반영", state="normal")
        
        if val == 0:
            messagebox.showwarning("인식 불가", f"'{text}'은(는) 칼로리 소모를 기록할 정도의 운동으로 보이지 않아요! (예: 숨쉬기, 손가락 움직이기 등)")
            return
        elif val == -1:
            messagebox.showinfo("정보 부족", f"'{text}'만으로는 칼로리 계산이 어려워요.\n몇 분 동안 했는지, 혹은 몇 km를 갔는지 정확히 말해주세요!")
            return

        self.burned_kcal += val
        self.exercise_entry.delete(0, 'end')
        messagebox.showinfo("💪 운동 추가 완료", f"[{intensity}] {text}\n약 {val}kcal 소모가 반영되었습니다!")
        self.save_data()
        self.update_dashboard()

    def analyze_physical(self):
        try:
            h = float(self.height_entry.get())
            w = float(self.weight_entry.get())
            goal = self.goal_var.get()
            
            # DB 저장
            self.phys_info = {"h": str(h), "w": str(w), "goal": goal}
            
            bmr = (10 * w) + (6.25 * h) - (5 * 25) + 5
            tdee = int(bmr * 1.5)
            
            if goal == "다이어트":
                target_kcal = tdee - 500
                p_ratio = 2.0
                advice_msg = "체지방 감량을 위해 유지 칼로리에서 500kcal를 줄였습니다.\n근손실을 막기 위해 단백질 비중을 높였으니 섭취를 잘 지켜주세요."
            elif goal == "벌크업":
                target_kcal = tdee + 500
                p_ratio = 1.8
                advice_msg = "근육 증량을 위해 유지 칼로리에서 500kcal를 늘렸습니다.\n탄수화물과 단백질을 든든히 섭취하여 수행능력을 끌어올리세요."
            else:
                target_kcal = tdee
                p_ratio = 1.6
                advice_msg = "현재 체중 유지를 위한 칼로리입니다.\n과식하지 않고 규칙적인 식사를 유지하는 것이 중요합니다."

            self.targets["kcal"] = target_kcal
            self.targets["p"] = int(w * p_ratio)
            self.targets["f"] = int(target_kcal * 0.25 / 9)
            self.targets["c"] = int((target_kcal - (self.targets["p"]*4) - (self.targets["f"]*9)) / 4)
            
            advice = f"당신의 피지컬({h}cm, {w}kg) 및 목표({goal}) 분석 결과입니다:\n\n"
            advice += f"{advice_msg}\n\n"
            advice += f"목표 달성을 위해 하루 {target_kcal}kcal 섭취를 권장합니다."
            
            self.advice_label.configure(text=advice)
            self.save_data()
            self.update_dashboard()
            messagebox.showinfo("분석 완료", f"[{goal}] 목표에 따른 맞춤 영양 목표가 설정/저장되었습니다.")
        except ValueError:
            messagebox.showerror("입력 오류", "키와 몸무게를 숫자로 올바르게 입력해주세요.")

    def add_food_smart(self):
        text = self.natural_input_entry.get().strip()
        if not text:
            return

        self.add_btn.configure(text="AI 실시간 분석 중... ⏳", state="disabled")

        def worker():
            try:
                client = Client()
                prompt = f"""
                Analyze this food input: "{text}".
                Return ONLY a JSON array of objects. 
                Each object MUST have: "name" (string, food name and quantity), "kcal" (number), "p" (number, protein in g), "c" (number, carbs in g), "f" (number, fat in g).
                Example: [{{"name": "김치찌개 1인분", "kcal": 400, "p": 25, "c": 20, "f": 25}}]
                DO NOT output markdown, ONLY raw JSON text.
                """
                response = client.chat.completions.create(
                    model="gpt-4",
                    messages=[{"role": "user", "content": prompt}],
                )
                res_text = response.choices[0].message.content.strip()
                if res_text.startswith("```json"):
                    res_text = res_text[7:-3].strip()
                elif res_text.startswith("```"):
                    res_text = res_text[3:-3].strip()
                
                data = json.loads(res_text)
                self.after(0, self.on_ai_finish, data, text, None)
            except Exception as e:
                self.after(0, self.on_ai_finish, None, text, str(e))
                
        threading.Thread(target=worker, daemon=True).start()

    def on_ai_finish(self, data, original_text, error):
        self.add_btn.configure(text="AI 스마트 분석 후 기록 추가", state="normal")
        if error or not data:
            self.fallback_local_db(original_text)
        else:
            for item in data:
                processed_item = {
                    "name": item.get("name", "알 수 없는 음식"),
                    "info": {
                        "kcal": float(item.get("kcal", 0)),
                        "p": float(item.get("p", 0)),
                        "c": float(item.get("c", 0)),
                        "f": float(item.get("f", 0))
                    }
                }
                self.daily_log.append(processed_item)
                
            self.natural_input_entry.delete(0, 'end')
            self.save_data()
            self.update_history()
            self.update_dashboard()
            self.check_status()

    def fallback_local_db(self, text):
        kor_nums = {"한": 1, "하나": 1, "두": 2, "둘": 2, "세": 3, "셋": 3, "네": 4, "넷": 4, "다섯": 5, "반": 0.5}
        found_items = []
        temp_text = text
        for food_name, data in FOOD_DB.items():
            if food_name in temp_text:
                qty = 1000.0
                num_match = re.search(r'(\d+(?:\.\d+)?)\s*(개|그릇|인분|마리|조각|잔|병|줄|캔|장)', temp_text)
                if num_match:
                    qty = float(num_match.group(1))
                else:
                    for k, v in kor_nums.items():
                        if re.search(f'{k}\\s*(개|그릇|인분|마리|조각|잔|병|줄|캔|장)', temp_text):
                            qty = v
                            break
                if qty == 1000.0: qty = 1.0
                    
                found_items.append({
                    "name": f"{food_name} {qty}{data['unit']} (오프라인)",
                    "info": {"kcal": data['kcal']*qty, "p": data['p']*qty, "c": data['c']*qty, "f": data['f']*qty}
                })
                temp_text = temp_text.replace(food_name, "")

        if not found_items:
            messagebox.showinfo("AI 분석 실패", f"분석에 실패했습니다. (인터넷 상태 확인 요망)")
            return

        for item in found_items:
            self.daily_log.append(item)
            
        self.natural_input_entry.delete(0, 'end')
        self.save_data()
        self.update_history()
        self.update_dashboard()
        self.check_status()

    def update_dashboard(self):
        totals = {"kcal": 0, "p": 0, "c": 0, "f": 0}
        for item in self.daily_log:
            totals["kcal"] += item["info"]["kcal"]
            totals["p"] += item["info"]["p"]
            totals["c"] += item["info"]["c"]
            totals["f"] += item["info"]["f"]

        # 운동 소모 칼로리를 본래 유지/설정 목표에 더해주어 '추가 섭취 가능량'을 반영
        target_kcal = self.targets.get("kcal", 2500) + self.burned_kcal
        t_p = self.targets.get("p", 150)
        t_c = self.targets.get("c", 300)
        t_f = self.targets.get("f", 70)

        # 프로그래스바 처리 (최대 1.0)
        self.kcal_card.configure(text=f"{int(totals['kcal'])} / {target_kcal} kcal")
        kcal_ratio = min(1.0, totals['kcal'] / target_kcal) if target_kcal > 0 else 0
        self.kcal_pb.set(kcal_ratio)
        self.kcal_pb.configure(progress_color="#ef4444" if kcal_ratio >= 1.0 else "#10b981")

        self.protein_card.configure(text=f"{totals['p']:.1f}g / {t_p}g")
        p_ratio = min(1.0, totals['p'] / t_p) if t_p > 0 else 0
        self.protein_pb.set(p_ratio)

        self.carbs_card.configure(text=f"{totals['c']:.1f}g / {t_c}g")
        c_ratio = min(1.0, totals['c'] / t_c) if t_c > 0 else 0
        self.carbs_pb.set(c_ratio)

        self.fat_card.configure(text=f"{totals['f']:.1f}g / {t_f}g")
        f_ratio = min(1.0, totals['f'] / t_f) if t_f > 0 else 0
        self.fat_pb.set(f_ratio)

    def check_status(self):
        totals = {"kcal": 0, "p": 0}
        for item in self.daily_log:
            totals["kcal"] += item["info"]["kcal"]
            totals["p"] += item["info"]["p"]

        target_kcal = self.targets.get("kcal", 2500) + self.burned_kcal
        
        if totals["kcal"] > target_kcal:
            res = "⚠️ 칼로리 섭취가 권장량을 초과했습니다. 유산소 운동 추가를 추천합니다!"
        elif totals["p"] < self.targets.get("p", 150) * 0.7:
            res = "🍗 단백질 섭취가 아직 부족합니다. 다음 식사에는 단백질을 챙겨보세요."
        else:
            res = "✅ 아주 좋은 균형입니다! 현재 수준의 식단을 지켜주시면 가장 좋습니다."
        
        self.advice_label.configure(text=res)

    def update_history(self):
        for widget in self.history_scroll.winfo_children():
            widget.destroy()
        for i, item in enumerate(self.daily_log):
            item_frame = ctk.CTkFrame(self.history_scroll, fg_color="transparent")
            item_frame.pack(fill="x", pady=2)
            label = ctk.CTkLabel(item_frame, text=f"· {item['name']}\n  {item['info']['kcal']}kcal (탄{item['info']['c']} 단{item['info']['p']} 지{item['info']['f']})", 
                                 font=ctk.CTkFont(size=12), justify="left")
            label.pack(side="left", padx=10)
            delete_btn = ctk.CTkButton(item_frame, text="삭제", width=40, height=20, fg_color="#ef4444", font=ctk.CTkFont(size=11), 
                                       command=lambda idx=i: self.delete_item(idx))
            delete_btn.pack(side="right", padx=10)

    def delete_item(self, index):
        self.daily_log.pop(index)
        self.save_data()
        self.update_history()
        self.update_dashboard()

if __name__ == "__main__":
    app = NutriLogApp()
    app.mainloop()
